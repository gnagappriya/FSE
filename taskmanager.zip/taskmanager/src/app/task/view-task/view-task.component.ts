import { Component, OnInit, ViewChild, AfterViewInit, ElementRef,OnDestroy } from '@angular/core';
import {TaskServiceService} from '../task-service.service';
import { FormGroup, FormControl } from '@angular/forms';
import {TaskManagerMaster,JsonResponse} from '../TaskManager';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-view-task',
  templateUrl: './view-task.component.html',
  styleUrls: ['./view-task.component.css']
})
export class ViewTaskComponent implements OnInit,AfterViewInit {

  //@ViewChild('startPopup') startPopup: ElementRef;

  ngAfterViewInit(){
    // setTimeout(()=>{
    //   this.startPopup.nativeElement.click();
    // },200);
  }

 
  taskViewForm = new FormGroup({
    task : new FormControl(''),
    parenttask : new FormControl(''),
    priorityfrom : new FormControl(''),
    priorityto : new FormControl(''),
    startdate : new FormControl(''),
    enddate: new FormControl('')

  });
public openModal1(content){

}
  
  taskmanagerlist : TaskManagerMaster[]=[] ;
  showDisableButton : boolean = true;

  constructor(public taskService : TaskServiceService) { }

  ngOnInit() {
    this.getTaskManagerMaster();
  }
  

  // open(content) {, private modalService: NgbModal
  //   this.modalService.open(content);
  // }
  public  getTaskManagerMaster(){
    console.log("In ViewTaskComponent - getTaskManagerMaster");
   
    this.taskService.getTaskManagerMaster().subscribe(data=>{
      console.log("test");
      if(data.taskmanagerlist !=null){
        this.taskmanagerlist = data.taskmanagerlist;
        console.log(this.taskmanagerlist);
      }
    });
   
  }

 public endTask( t){
    console.log("In ViewTaskComponent - endTask");
   
    this.taskService.endTask(t);

    this.taskService.endTask(t).subscribe(data=>{
      console.log(data);
      if(data.taskmanagerlist !=null){
        this.taskmanagerlist = data.taskmanagerlist;
        console.log(this.taskmanagerlist);
        
      }
      this.getTaskManagerMaster();
    });
    
  }

  checkBusttonStatus(taskStatus):boolean{
  if(taskStatus=="SUSPENDED"){
    return true;
  }
  else{
    return false;
  }
}
}
