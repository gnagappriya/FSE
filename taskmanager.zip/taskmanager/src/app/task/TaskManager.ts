export class TaskManager{
parenttask : string;
task : string;
startdate : string;
enddate : string;
priority : number;
error: string;
priorityfrom: string;
priorityto :string;
}
export class JsonResponse{
	taskmanagerlist : TaskManagerMaster[];
	status : string;
}

export class TaskManagerMaster{
     task : string ;
	 startdate : string ;
	 enddate : string ;
	 priority : string ;
	 parentTask : string ;
	 taskstatus: string ;
}


