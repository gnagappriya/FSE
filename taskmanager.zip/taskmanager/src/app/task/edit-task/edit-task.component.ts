import { Component, OnInit , Input, Output, EventEmitter} from '@angular/core';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-edit-task',
  templateUrl: './edit-task.component.html',
  styleUrls: ['./edit-task.component.css']
})
export class EditTaskComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  @Output() childEvent = new EventEmitter();
  taskEditForm = new FormGroup({
    task : new FormControl(''),
    parenttask : new FormControl(''),
    priorityfrom : new FormControl(''),
    priorityto : new FormControl(''),
    startdate : new FormControl(''),
    enddate: new FormControl('')

  });
  @Input() editTaskInput: string;

}
