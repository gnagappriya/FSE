import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-end-task',
  templateUrl: './end-task.component.html',
  styleUrls: ['./end-task.component.css']
})
export class EndTaskComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
