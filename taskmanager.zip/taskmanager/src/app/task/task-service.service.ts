import {HttpClient } from '@angular/common/http';
import {Injectable} from '@angular/core';
import {TaskManager,TaskManagerMaster,JsonResponse} from '../task/TaskManager';

@Injectable({
  providedIn: 'root'
})
export class TaskServiceService {

  constructor(public http: HttpClient) { }


  addTask(tm:TaskManager ){
    console.log("Calling service - http://localhost:8082/taskManager/addTask")
    
    return this.http.post<TaskManager>('http://localhost:8082/taskManager/addTask',tm);
  }

  getTaskManagerMaster(){
    console.log ("calling service - http://localhost:8082/taskManager/getAllTasks");
    return this.http.get<JsonResponse>('http://localhost:8082/taskManager/getAllTasks');
  }


  endTask(t:TaskManagerMaster){
    console.log ("calling service - http://localhost:8082/taskManager/suspendTask");
    let url ="http://localhost:8082/taskManager/suspendTask/";
    
    console.log (t)
    let response  = this.http.post<JsonResponse>(url, t);
    return response;
  }
}
