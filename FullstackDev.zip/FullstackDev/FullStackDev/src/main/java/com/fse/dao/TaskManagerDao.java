package com.fse.dao;

import java.util.List;

import com.fse.entity.ParentTaskTable;
import com.fse.model.TaskManagerMaster;

public interface TaskManagerDao {
	public String addTask(ParentTaskTable ptt);
	public List<TaskManagerMaster> getAllTasks();
	public List<TaskManagerMaster> suspendTask(TaskManagerMaster taskManagerMaster);
}
